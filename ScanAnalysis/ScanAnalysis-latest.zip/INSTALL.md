# ScanAnalysis Installation

## Quick Install

1. Right-click on `Install-ScanAnalysis.ps1` and select **Run with PowerShell**
2. Select which Revit version(s) to install
3. Wait for installation to complete
4. Restart Revit

## Manual Install

If the PowerShell installer doesn't work:

1. Copy the `ScanAnalysis` folder from `Revit20XX` (matching your version) to:
   `%APPDATA%\Autodesk\Revit\Addins\20XX\`

2. Copy `ScanAnalysis.addin` from `Revit20XX` to:
   `%APPDATA%\Autodesk\Revit\Addins\20XX\`

3. Install WebView2 runtime (for 360 panorama viewer):
   https://developer.microsoft.com/en-us/microsoft-edge/webview2/

## Requirements

- Autodesk Revit 2023, 2024, 2025, or 2026
- CloudCompare (https://cloudcompare.org/) for deviation analysis
- WebView2 runtime (installed automatically by the installer)

## Uninstall

Run the installer with the -Uninstall flag:
```powershell
.\Install-ScanAnalysis.ps1 -Uninstall
```

## Support

For documentation and updates, visit:
https://kamditis.github.io/
