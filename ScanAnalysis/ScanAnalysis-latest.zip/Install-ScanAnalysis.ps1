<#
.SYNOPSIS
    Installs ScanAnalysis Revit Add-in

.DESCRIPTION
    This script installs the ScanAnalysis add-in for Autodesk Revit.
    It supports Revit 2023, 2024, 2025, and 2026.
    It also installs WebView2 runtime if not already present.

.PARAMETER RevitVersions
    Array of Revit versions to install (e.g., "2024", "2025")
    If not specified, user will be prompted to select.

.PARAMETER Uninstall
    Removes the add-in instead of installing it.

.PARAMETER Silent
    Runs without user prompts (requires RevitVersions parameter)

.EXAMPLE
    .\Install-ScanAnalysis.ps1
    Runs the installer with interactive prompts.

.EXAMPLE
    .\Install-ScanAnalysis.ps1 -RevitVersions "2024","2025"
    Installs for Revit 2024 and 2025 without prompts.

.EXAMPLE
    .\Install-ScanAnalysis.ps1 -Uninstall
    Removes the add-in from all Revit versions.
#>

param(
    [string[]]$RevitVersions,
    [switch]$Uninstall,
    [switch]$Silent
)

$ErrorActionPreference = "Stop"

# Configuration
$AddinName = "ScanAnalysis"
$SupportedVersions = @("2023", "2024", "2025", "2026")
$WebView2InstallerUrl = "https://go.microsoft.com/fwlink/p/?LinkId=2124703"
$ScriptDir = $PSScriptRoot

# Helper functions
function Write-Header {
    param([string]$Text)
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  $Text" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Step {
    param([string]$Text)
    Write-Host "[*] $Text" -ForegroundColor White
}

function Write-Success {
    param([string]$Text)
    Write-Host "[+] $Text" -ForegroundColor Green
}

function Write-Warning {
    param([string]$Text)
    Write-Host "[!] $Text" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Text)
    Write-Host "[-] $Text" -ForegroundColor Red
}

function Test-WebView2Installed {
    # Check if WebView2 runtime is installed
    $webview2Key = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
    $webview2Key2 = "HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
    $webview2KeyUser = "HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"

    return (Test-Path $webview2Key) -or (Test-Path $webview2Key2) -or (Test-Path $webview2KeyUser)
}

function Install-WebView2 {
    Write-Step "Checking WebView2 runtime..."

    if (Test-WebView2Installed) {
        Write-Success "WebView2 runtime is already installed."
        return $true
    }

    Write-Warning "WebView2 runtime is not installed."
    Write-Step "Downloading WebView2 bootstrapper..."

    $bootstrapperPath = "$env:TEMP\MicrosoftEdgeWebview2Setup.exe"

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $WebView2InstallerUrl -OutFile $bootstrapperPath -UseBasicParsing

        Write-Step "Installing WebView2 runtime (this may take a minute)..."
        $process = Start-Process -FilePath $bootstrapperPath -ArgumentList "/silent /install" -Wait -PassThru

        if ($process.ExitCode -eq 0) {
            Write-Success "WebView2 runtime installed successfully."
            return $true
        }
        else {
            Write-Error "WebView2 installation failed with exit code: $($process.ExitCode)"
            return $false
        }
    }
    catch {
        Write-Error "Failed to download/install WebView2: $_"
        Write-Warning "Please install WebView2 manually from: https://developer.microsoft.com/en-us/microsoft-edge/webview2/"
        return $false
    }
    finally {
        if (Test-Path $bootstrapperPath) {
            Remove-Item $bootstrapperPath -Force -ErrorAction SilentlyContinue
        }
    }
}

function Get-RevitAddinFolder {
    param([string]$Version)
    return "$env:APPDATA\Autodesk\Revit\Addins\$Version"
}

function Test-RevitInstalled {
    param([string]$Version)
    $addinFolder = Get-RevitAddinFolder -Version $Version
    $revitPath = "C:\Program Files\Autodesk\Revit $Version"
    return (Test-Path $revitPath) -or (Test-Path $addinFolder)
}

function Get-InstalledRevitVersions {
    $installed = @()
    foreach ($version in $SupportedVersions) {
        if (Test-RevitInstalled -Version $version) {
            $installed += $version
        }
    }
    return $installed
}

function Show-VersionMenu {
    $installedVersions = Get-InstalledRevitVersions

    if ($installedVersions.Count -eq 0) {
        Write-Warning "No supported Revit versions detected."
        Write-Host "Supported versions: $($SupportedVersions -join ', ')"
        Write-Host ""
        Write-Host "You can still install for a specific version."
        $installedVersions = $SupportedVersions
    }

    Write-Host "Select Revit version(s) to install:" -ForegroundColor White
    Write-Host ""

    for ($i = 0; $i -lt $installedVersions.Count; $i++) {
        $version = $installedVersions[$i]
        $detected = if (Test-RevitInstalled -Version $version) { " (detected)" } else { "" }
        Write-Host "  [$($i + 1)] Revit $version$detected"
    }
    Write-Host ""
    Write-Host "  [A] All versions"
    Write-Host "  [Q] Quit"
    Write-Host ""

    $selection = Read-Host "Enter selection (e.g., 1,2 or A)"

    if ($selection -eq "Q" -or $selection -eq "q") {
        return @()
    }

    if ($selection -eq "A" -or $selection -eq "a") {
        return $installedVersions
    }

    $selected = @()
    $indices = $selection -split "," | ForEach-Object { $_.Trim() }

    foreach ($index in $indices) {
        if ($index -match "^\d+$") {
            $i = [int]$index - 1
            if ($i -ge 0 -and $i -lt $installedVersions.Count) {
                $selected += $installedVersions[$i]
            }
        }
    }

    return $selected
}

function Install-Addin {
    param([string]$Version)

    Write-Step "Installing for Revit $Version..."

    $addinFolder = Get-RevitAddinFolder -Version $Version
    $targetFolder = "$addinFolder\$AddinName"

    # Determine source folder
    $sourceFolder = "$ScriptDir\Revit$Version"

    if (!(Test-Path $sourceFolder)) {
        # Try alternative locations
        $altSource = "$ScriptDir\..\dist\Revit$Version"
        if (Test-Path $altSource) {
            $sourceFolder = $altSource
        }
        else {
            Write-Error "Source files not found for Revit $Version"
            Write-Host "  Expected: $sourceFolder"
            return $false
        }
    }

    try {
        # Create addin folder if it doesn't exist
        if (!(Test-Path $addinFolder)) {
            New-Item -ItemType Directory -Path $addinFolder -Force | Out-Null
        }

        # Remove existing installation
        if (Test-Path $targetFolder) {
            Write-Step "  Removing existing installation..."
            Remove-Item -Path $targetFolder -Recurse -Force
        }

        # Remove existing manifest
        $existingManifest = "$addinFolder\$AddinName.addin"
        if (Test-Path $existingManifest) {
            Remove-Item -Path $existingManifest -Force
        }

        # Check if source has the new structure (ScanAnalysis subfolder)
        $dllSubfolder = "$sourceFolder\$AddinName"
        if (Test-Path $dllSubfolder) {
            # New structure: ScanAnalysis.addin + ScanAnalysis/ subfolder
            Write-Step "  Copying files (new structure)..."

            # Copy the ScanAnalysis subfolder to target
            Copy-Item -Path $dllSubfolder -Destination $addinFolder -Recurse -Force

            # Copy .addin manifest to addins folder
            $addinManifest = Get-ChildItem -Path $sourceFolder -Filter "*.addin" -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($addinManifest) {
                Copy-Item -Path $addinManifest.FullName -Destination $addinFolder -Force
            }
        }
        else {
            # Legacy flat structure: all files at root
            Write-Step "  Copying files (legacy structure)..."
            New-Item -ItemType Directory -Path $targetFolder -Force | Out-Null
            Copy-Item -Path "$sourceFolder\*" -Destination $targetFolder -Recurse -Force

            # Copy .addin manifest to parent folder
            $addinManifest = Get-ChildItem -Path $sourceFolder -Filter "*.addin" -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($addinManifest) {
                Copy-Item -Path $addinManifest.FullName -Destination $addinFolder -Force
            }
        }

        Write-Success "Installed for Revit $Version"
        Write-Host "    Location: $targetFolder" -ForegroundColor Gray
        return $true
    }
    catch {
        Write-Error "Failed to install for Revit $Version : $_"
        return $false
    }
}

function Uninstall-Addin {
    param([string]$Version)

    Write-Step "Uninstalling from Revit $Version..."

    $addinFolder = Get-RevitAddinFolder -Version $Version
    $targetFolder = "$addinFolder\$AddinName"
    $manifestPath = "$addinFolder\$AddinName.addin"

    $removed = $false

    try {
        if (Test-Path $targetFolder) {
            Remove-Item -Path $targetFolder -Recurse -Force
            $removed = $true
        }

        if (Test-Path $manifestPath) {
            Remove-Item -Path $manifestPath -Force
            $removed = $true
        }

        if ($removed) {
            Write-Success "Uninstalled from Revit $Version"
        }
        else {
            Write-Warning "Add-in was not installed for Revit $Version"
        }

        return $true
    }
    catch {
        Write-Error "Failed to uninstall from Revit $Version : $_"
        return $false
    }
}

# Main script
Write-Header "$AddinName Installer"

if ($Uninstall) {
    Write-Host "Uninstall mode" -ForegroundColor Yellow
    Write-Host ""

    if ($RevitVersions.Count -eq 0) {
        $RevitVersions = $SupportedVersions
    }

    foreach ($version in $RevitVersions) {
        Uninstall-Addin -Version $version
    }

    Write-Host ""
    Write-Success "Uninstall complete!"
    exit 0
}

# Install mode
if ($RevitVersions.Count -eq 0 -and !$Silent) {
    $RevitVersions = Show-VersionMenu
}

if ($RevitVersions.Count -eq 0) {
    Write-Warning "No versions selected. Exiting."
    exit 0
}

Write-Host "Installing for: $($RevitVersions -join ', ')" -ForegroundColor White
Write-Host ""

# Install WebView2
$webview2Ok = Install-WebView2
if (!$webview2Ok -and !$Silent) {
    Write-Host ""
    $continue = Read-Host "Continue without WebView2? (360 panorama viewer will not work) [y/N]"
    if ($continue -ne "y" -and $continue -ne "Y") {
        exit 1
    }
}

Write-Host ""

# Install for each version
$successCount = 0
foreach ($version in $RevitVersions) {
    if (Install-Addin -Version $version) {
        $successCount++
    }
}

Write-Host ""
Write-Header "Installation Complete"

if ($successCount -eq $RevitVersions.Count) {
    Write-Success "Successfully installed for all selected versions!"
}
else {
    Write-Warning "Installed for $successCount of $($RevitVersions.Count) versions."
}

Write-Host ""
Write-Host "Next steps:" -ForegroundColor White
Write-Host "  1. Close and restart Revit"
Write-Host "  2. Look for the 'Scan Analysis' tab in the ribbon"
Write-Host ""

if (!$Silent) {
    Read-Host "Press Enter to exit"
}
